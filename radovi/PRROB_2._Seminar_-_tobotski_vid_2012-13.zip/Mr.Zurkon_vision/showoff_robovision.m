%params
slika = './vision/8_image.jpg'
pixel_clean_extent = 15
min_diam = 40
max_length_center_IDs = 80

        %clf
        %
        %hFig = figure(1);
        %set(hFig, 'Position', [0 200 600 400]);

        %set(hFig, 'Position', [0 200 1280 400]);

        % ignoriraj sljdeci warning
        warning('OFF', 'MATLAB:imagesci:tifftagsread:badTagValueDivisionByZero');


        %ucitaj osnovnu sliku, biraj koju ces
        rgb = imread(slika);

        %imshow(slika)
        %rgb = imread('00000001.png');

        %grayscale za daljnju obradu
        %gray = rgb2gray(rgb);

        %   Trazimo boje

        img = im2double(rgb);
        %[r c p] = size(img);

        imR = squeeze(img(:, :, 1));
        imG = squeeze(img(:, :, 2));
        imB = squeeze(img(:, :, 3));

        imBinaryR = im2bw(imR, graythresh(imR));
        imBinaryG = im2bw(imG, graythresh(imG));
        imBinaryB = im2bw(imB, graythresh(imB));

        imBinary = imcomplement(imBinaryR&imBinaryG&imBinaryB);

		
		%imClean = imBinary;
        %brisi sve objekte koji diraju rubove, mora sve biti unutar slike
        imClean = imclearborder(imBinary);
		
        %imClean = bwareaopen(imBinary, 10);
        %imshow(imClean)
        %Filtracija morph
        se = strel('disk', pixel_clean_extent); % pazi na velicinu snimljenih krugova, rezulucija!
        imClean = imopen(imClean, se);



        %fill holes clear borders
        imClean = imfill(imClean, 'holes');


        %labling zeit
        [labels, numLabels] = bwlabel(imClean, 4); %moguc problem s rezolucijom


        % !nekoristen dio koda
        % Sljedeci kod vadi sliku objekata po medijanima boja svakog objekta
        % Svrha je vizualan prikaz za krajnjeg korisnika, no moguce da se ne 
        % koristi u krajnjem kodu zbog velikog memorijskog zahtjeva matrica
        if 0
        %Init matrice
            rLabel = zeros(r, c);
            gLabel = zeros(r, c);
            bLabel = zeros(r, c);

            %Get avarage color vector for each object (labeled region)
            for i=1:numLabels
                rLabel(labels==i) = median(imR(labels==i));
                gLabel(labels==i) = median(imG(labels==i));
                bLabel(labels==i) = median(imB(labels==i));

            end

            % slika kombinacije sva tri vektora boje
             imLabel = cat(3, rLabel, gLabel, bLabel);


            % repakiranje u bw za bwboundries
            I = rgb2gray(imLabel);
            threshold = graythresh(I);
            bw = im2bw(I,threshold);


        else
            % Ukoliko se gornji kod ne koristi, snabdjevamo prijasnje prociscenu 
            % bw sliku za daljnju obradu
            bw = imClean;
        end




        % Detekcija SVIH objekata i njihovih svojstava, potrebni za daljnu obradu
        stats = regionprops(bw, 'Centroid', 'Orientation', 'BoundingBox', ...
             'MajorAxisLength', 'Eccentricity', 'EquivDiameter');




        % Koeficijenti detekcije objekata, kruznice i pravokutnici
        center_marks = find(([stats.Eccentricity] > 0.9).*( ...
            [stats.MajorAxisLength] < max_length_center_IDs));
        
        rectangles = find(([stats.Eccentricity] > 0.9).*( ...
            [stats.MajorAxisLength] > max_length_center_IDs));
        
        
        circles = find(([stats.Eccentricity] < 0.55).*( ...
            [stats.EquivDiameter] > min_diam));


        % bitno za rezoluciju i ovisi o kvaliteti slike!

        %stats.Eccentricity
        %stats.EquivDiameter

        % Izracunaj pozicije ulazne i izlazne tocke iz detektora
        % ukoliko nismo nasli 2 (ili vise, sto nije dobro) detektora, nemoj ni
        % pokusavati to izvesti

        
        if length(rectangles) >= 2
            rec1 = stats(rectangles(1));
            rec2 = stats(rectangles(2));


            midpoint = (rec1.Centroid + rec2.Centroid)/2;

            %plot(midpoint(1), midpoint(2), 'cd');


            med_orient =  -(rec1.Orientation + rec2.Orientation)/2;
            med_big_axis = (rec1.MajorAxisLength + rec2.MajorAxisLength)/2;


            % Koef regulira koliko ce biti udaljena ulazna tocka od kraja regulatora
            koef_razmaka = 1.3;
            half_big = med_big_axis/2 * koef_razmaka;


            y_offset = sind(med_orient)*half_big;
            x_offset = cosd(med_orient)*half_big;



            l_tocka = [(midpoint(1) - x_offset) (midpoint(2) - y_offset)];
            r_tocka = [(midpoint(1) + x_offset) (midpoint(2) + y_offset)];

            % Izracunaj udaljenost dvaju detektora (Od sredista detektora!)
            dist_det = sqrt((rec1.Centroid(2) - rec2.Centroid(2))^2 + ...
                (rec1.Centroid(1) - rec2.Centroid(1))^2);

        else
            disp(['Prijatelju imas ',  num2str(length(rectangles)), ... 
                ' pronadjenih pravokutnika na slici...']);

        end
        % identifikator boje
        id_color = zeros(numLabels, 3);


        % Pametno je zapamtiti medijane boja koje smo dobili u prijasnjem kodu,
        % iste cemo koristiti kao identifikatore objekata za selekciju u
        % upravljackoj funkciji naseg NXT robota
        for i = 1:numLabels
           id_color(i, :) = [median(imR(labels==i)), median(imG(labels==i)), ...
               median(imB(labels==i)) ];

           %posvijetli malo vrijednosti da se markeri bolje vide na slici
           id_color(i, :) = id_color(i, :)+ [0.2 0.2 0.2];

        end

        %center_marks
        %izracunaj srediste koordinatnog sustava pomocu oznaka centra
         if length(center_marks) == 2
            % postoje tocno dvije oznake
             sys_center = (stats(center_marks(1)).Centroid + ...
                 stats(center_marks(2)).Centroid)/2;
         
         else
            disp('Ne postoje dvije oznake centra, nije definirano ishodiste sustava!');
         end
         
        

        % crtaj sliku,
        % image_markup funkcija oznacava sliku, live feed se crta direktno u
        % GUI-u

        %imshow(rgb) %, 'InitialMagnification', 'fit')
        %hold on

        % info pozicije
        %impixelinfo(gcf);

        %
        % Objekti koji su ili pravokutnici ili krugovi
        zanimljivi = horzcat(rectangles, circles, center_marks);

        % Daj nesto feedbacka

        disp(['Identificirano zanimljivih objekata [od ukupno]: ' ...
            num2str(length(zanimljivi)), ' [',num2str(numLabels), '] ']);


        % Nadji rubove SAMO DOBRIH objekata, zanemari embedane objekte
        % koje smo i filtracijom ocistili
        [B,L] = bwboundaries(bw,'noholes');


        %
        % Isctraj sve vrste oznaka objekata i kljucnih tocaka u prostoru za potrebe
        % vizualne provjere da li nas robotski vid radi ispravno...

        %ne crtamo nista, to obavlja funkcija image_markup
        if 0

            % Crtamo si malo rubove, bojamo po medijanima boja objekata
            for k = zanimljivi
              boundary = B{k};
              %identifikator boje
              plot(boundary(:,2), boundary(:,1), 'Color', id_color(k, :), 'LineWidth', 4)
              % razmak da je boja uocljivija
              %plot(boundary(:,2), boundary(:,1), 'black', 'LineWidth', 2)
            end

            % Iscrtaj centre objekata
            for object = zanimljivi
                bc = stats(object).Centroid;
                if any(object == rectangles)    % Pravokutnike pink krizem
                    style = 'm+';
                elseif any(object == circles)   % Krugove zelenim krizem
                    style = 'g+';
                else                            % sve ostalo smedjim krizem,               
                    style = 'b+';               % dalje nas ne interesiraju ti objekti
                end
                plot(bc(1), bc(2), style, 'MarkerSize', 12)

            end

            %ukoliko nemamo pravokutnika, nemamo ni koje tocke iscrtati

            if length(rectangles) >= 2

                % Iscrtaj liniju prolaska kroz detektore
                x = [l_tocka(1), midpoint(1), r_tocka(1)];
                y = [l_tocka(2), midpoint(2), r_tocka(2)];

                % koristi patch za fancy proziran efekt, nema alpha na obicne plot
                % linije
                xflip = [x(1 : end - 1) fliplr(x)];
                yflip = [y(1 : end - 1) fliplr(y)];
                patch(xflip, yflip, 'r', 'EdgeAlpha', 0.2, 'FaceColor', 'none', ...
                    'linewidth', 5, 'EdgeColor', 'cyan');
                %p = patchline(xflip,yflip,'linestyle','--','edgecolor','g', ...
                %'linewidth',3,'edgealpha',0.2);

                % Iscrtaj midpoint izmedju detektora, diamond
                plot(midpoint(1), midpoint(2), 'bd', 'MarkerSize', 10, ...
                    'MarkerFaceColor', 'b');

                % Iscrtaj pozicije ulazne i izlazne tocke iz detektora, ocekuju se samo
                % dvije, moguce prosiriti na vise detektora i ploca
                plot(l_tocka(1), l_tocka(2), 'y^', 'MarkerSize', 10);
                plot(r_tocka(1), r_tocka(2), 'r^', 'MarkerSize', 10);

            end
        end

        % Format structure for output

        if length(rectangles) >= 2

            %pozicije koje znace 
            points_rec.midpoint = midpoint;
            points_rec.l_point = l_tocka;
            points_rec.r_point = r_tocka;
        else
            points_rec = [];
        end

        
        if length(center_marks) == 2
            sys_center_out = sys_center;
        
        else
            sys_center_out = [];
        end
        if length(rectangles) >= 1
            %malo o pravokutnicima
            for i = 1:length(rectangles)
                out_rectangles(i).ID_NR = i;
                out_rectangles(i).color = id_color(rectangles(i), :);
                out_rectangles(i).Centroid = stats(rectangles(i)).Centroid;
            end
        else
            out_rectangles = [];
        end

        if length(circles) >= 1

            %malo o kruznicama
            for i = 1:length(circles)
                out_circles(i).ID_NR = i;
                out_circles(i).Color = id_color(circles(i), :);
                out_circles(i).Centroid = stats(circles(i)).Centroid;
                out_circles(i).Diameter = stats(circles(i)).EquivDiameter;

            end
        else
            out_circles = [];
        end


        % output za image_markup funkciju 
        boundries_out.B = B;
        %boundries_out.L = L
        boundries_out.k = zanimljivi;
        boundries_out.id_color = id_color;



        
        % plotaj sve sto postoji
        
        subplot(2,3,1), imshow(img);
        subplot(2,3,2), imshow(imR);
        subplot(2,3,3), imshow(imG);
        
        
        subplot(2,3,4), imshow(imB);
        subplot(2,3,5), imshow(imBinary);
        subplot(2,3,6), imshow(imClean);
        
       % hax = axes('Position', [.35, .05, .35, .3]);
       % bar(hax,y,'EdgeColor','none')
        
        
      %  imshow( imClean, 'Parent', hax);
        hold on
        
         if 1

            % Crtamo si malo rubove, bojamo po medijanima boja objekata
            for k = zanimljivi
              boundary = B{k};
              %identifikator boje
              plot(boundary(:,2), boundary(:,1), 'Color', id_color(k, :), 'LineWidth', 4)
              % razmak da je boja uocljivija
              %plot(boundary(:,2), boundary(:,1), 'black', 'LineWidth', 2)
            end

            % Iscrtaj centre objekata
            for object = zanimljivi
                bc = stats(object).Centroid;
                if any(object == rectangles)    % Pravokutnike pink krizem
                    style = 'm+';
                elseif any(object == circles)   % Krugove zelenim krizem
                    style = 'g+';
                else                            % sve ostalo smedjim krizem,               
                    style = 'b+';               % dalje nas ne interesiraju ti objekti
                end
                plot(bc(1), bc(2), style, 'MarkerSize', 12)

            end

            %ukoliko nemamo pravokutnika, nemamo ni koje tocke iscrtati

            if length(rectangles) >= 2

                % Iscrtaj liniju prolaska kroz detektore
                x = [l_tocka(1), midpoint(1), r_tocka(1)];
                y = [l_tocka(2), midpoint(2), r_tocka(2)];

                % koristi patch za fancy proziran efekt, nema alpha na obicne plot
                % linije
                xflip = [x(1 : end - 1) fliplr(x)];
                yflip = [y(1 : end - 1) fliplr(y)];
                patch(xflip, yflip, 'r', 'EdgeAlpha', 0.2, 'FaceColor', 'none', ...
                    'linewidth', 5, 'EdgeColor', 'cyan');
                %p = patchline(xflip,yflip,'linestyle','--','edgecolor','g', ...
                %'linewidth',3,'edgealpha',0.2);

                % Iscrtaj midpoint izmedju detektora, diamond
                plot(midpoint(1), midpoint(2), 'bd', 'MarkerSize', 10, ...
                    'MarkerFaceColor', 'b');

                % Iscrtaj pozicije ulazne i izlazne tocke iz detektora, ocekuju se samo
                % dvije, moguce prosiriti na vise detektora i ploca
                plot(l_tocka(1), l_tocka(2), 'y^', 'MarkerSize', 10);
                plot(r_tocka(1), r_tocka(2), 'r^', 'MarkerSize', 10);

            end
        end
